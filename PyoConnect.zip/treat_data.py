import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.decomposition import FastICA, PCA
from UliEngineering.SignalProcessing.Utils import zero_crossings
import matplotlib.pyplot as plt

def scaler(df):
    scaler = preprocessing.MinMaxScaler(feature_range=(-127, 127))
    df.iloc[:, 2:10] = pd.DataFrame(scaler.fit_transform(df.iloc[:, 2:10]), columns=df.columns[2:10])
    return df

def calc_row_mean_and_variance(df):
    df['Sensor Mean']       = df.iloc[:, 2:10].abs().mean(axis=1)
    df['Sensor Variance']   = df.iloc[:, 2:10].var(axis=1)
    df['Gyro Mean']       = df.iloc[:, 10:13].abs().mean(axis=1)
    df['Gyro Variance']   = df.iloc[:, 10:13].var(axis=1)
    df['Orientation Mean']       = df.iloc[:, 13:18].abs().mean(axis=1)
    df['Orientation Variance']   = df.iloc[:, 13:10].var(axis=1)
    return df

def calc_mean_and_variance(df):
    all_means = []
    all_vars = []
    for i in range(8):
        mean = df["Sensor " + str(i)].abs().mean(axis=0)
        var = df["Sensor " + str(i)].var(axis=0)
        all_means.append(mean)
        all_vars.append(var)
        print("Sensor {} absolute mean and variance: {}  /  {}".format(i, mean, var))
    return all_means, all_vars

def calc_zero(df):
    sensors_zeros = []
    for i in range(8):
        column = df["Sensor " + str(i)]
        zeros = zero_crossings(column)
        sensors_zeros.append(len(zeros))
        print("Checking the zeros found for sensor {}: ".format(i))
        for i in zeros:
            print(column[i], column[i+1])
    return sensors_zeros

def calc_ica_pca(mean, variance, zeros, wave_length=None, wilson_amp=None): # falta 1 eu acho
    features = [mean, variance, zeros]
    print(features)
    ica = FastICA(n_components=3) # numero de features?
    S_ = ica.fit_transform(features)  # Reconstruct signals
    A_ = ica.mixing_  # Get estimated mixing matrix

    # We can `prove` that the ICA model applies by reverting the unmixing.
    #assert np.allclose(features, np.dot(S_, A_.T) + ica.mean_)

    # For comparison, compute PCA
    pca = PCA(n_components=3)
    H = pca.fit_transform(features)  # Reconstruct signals based on orthogonal components
    print(S_, H)

data = pd.read_csv('./datasets/myo-parado-david3-2019-05-09 10:32:57-.csv')
print(data.head(10))
scaled_data = scaler(data)
print(scaled_data.head(10))

print("----------------------")
zeros = calc_zero(scaled_data)
print("----------------------")
all_means, all_vars = calc_mean_and_variance(scaled_data)
print("----------------------")
calc_ica_pca(mean=all_means, variance=all_vars, zeros=zeros)
print("----------------------")
